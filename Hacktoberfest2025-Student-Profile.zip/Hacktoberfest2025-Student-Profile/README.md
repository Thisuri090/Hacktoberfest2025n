# Student-Portfolio

A simple static site to showcase student portfolios. Add your own portfolio under `src/contributors/<YourName>/`.

## How to contribute

1. Fork the repo.
2. Create a folder `src/contributors/YourName/`.
3. Add `YourName.html`, `YourName.css`, `YourName.js`, and optional `images/`.
4. Add an entry to `src/contributors/contributors.json`, e.g.:

```json
{
  "name": "Your Name",
  "file": "src/contributors/YourName/YourName.html",
  "github": "https://github.com/yourusername",
  "linkedin": "https://www.linkedin.com/in/yourprofile/",
  "avatar": "src/contributors/YourName/images/avatar.png",
  "role": "Student / Developer",
  "short": "Short one-line bio"
}
