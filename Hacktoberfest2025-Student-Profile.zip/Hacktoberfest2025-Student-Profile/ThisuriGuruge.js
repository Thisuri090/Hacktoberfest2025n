// Small local behavior (example): log when profile loaded
console.log('Loaded ThisuriGuruge profile');
