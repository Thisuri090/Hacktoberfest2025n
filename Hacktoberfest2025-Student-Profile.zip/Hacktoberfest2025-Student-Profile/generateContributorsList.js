// Generates contributor cards, handles search, sort, random, and count.
// Depends on loadContributorsJson defined in contributors.js

document.addEventListener('DOMContentLoaded', async () => {
  const grid = document.getElementById('contributorsGrid');
  const search = document.getElementById('search');
  const sortSelect = document.getElementById('sort');
  const countEl = document.getElementById('contributorCount');
  const randomBtn = document.getElementById('randomBtn');

  let contributors = await window.loadContributorsJson();

  // Helper: normalize name for search and sort
  function nameKey(item) {
    return (item.name || '').toLowerCase();
  }

  function renderList(list) {
    grid.innerHTML = '';
    if (!Array.isArray(list) || list.length === 0) {
      grid.innerHTML = '<p>No contributors yet — add your portfolio in <code>src/contributors/</code>.</p>';
      countEl.textContent = '0 Contributors';
      return;
    }

    countEl.textContent = `${list.length} Contributor${list.length>1?'s':''}`;

    list.forEach(item => {
      const card = document.createElement('article');
      card.className = 'card contributor-card';
      card.dataset.name = item.name || '';

      const avatarUrl = item.avatar || 'https://via.placeholder.com/160x160.png?text=Avatar';
      card.innerHTML = `
        <div style="display:flex;gap:0.75rem;align-items:center">
          <img class="avatar" src="${avatarUrl}" alt="${item.name} avatar" loading="lazy" />
          <div style="flex:1">
            <h3>${item.name || 'Unnamed'}</h3>
            <p>${item.role || ''}</p>
          </div>
        </div>
        <p>${item.short || ''}</p>
        <div class="links">
          <a href="${item.file}" target="_blank" rel="noopener">View Portfolio</a>
          ${item.github ? `<a href="${item.github}" target="_blank" rel="noopener">GitHub</a>` : ''}
          ${item.linkedin ? `<a href="${item.linkedin}" target="_blank" rel="noopener">LinkedIn</a>` : ''}
        </div>
      `;

      grid.appendChild(card);
    });
  }

  // Initial render
  contributors = contributors.slice(); // clone
  renderList(contributors);

  // Search
  search.addEventListener('input', (e) => {
    const q = e.target.value.trim().toLowerCase();
    const filtered = contributors.filter(c => (c.name || '').toLowerCase().includes(q) || (c.short || '').toLowerCase().includes(q));
    renderList(filtered);
  });

  // Sort
  sortSelect.addEventListener('change', () => {
    const val = sortSelect.value;
    const sorted = contributors.slice().sort((a,b) => {
      if (val === 'name-asc') return nameKey(a).localeCompare(nameKey(b));
      if (val === 'name-desc') return nameKey(b).localeCompare(nameKey(a));
      return 0;
    });
    renderList(sorted);
  });

  // Random
  randomBtn.addEventListener('click', () => {
    if (!contributors.length) return;
    const idx = Math.floor(Math.random() * contributors.length);
    const c = contributors[idx];
    // open contributor file in new tab
    window.open(c.file, '_blank', 'noopener');
  });
});
