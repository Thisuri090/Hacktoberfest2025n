// This file loads contributors.json and exposes it to the rest of the UI.
// It simply fetches and returns JSON. Keep it simple and testable.

async function loadContributorsJson() {
  try {
    const resp = await fetch('src/contributors/contributors.json', {cache: "no-store"});
    if (!resp.ok) throw new Error('Failed to fetch contributors.json');
    const data = await resp.json();
    return data;
  } catch (err) {
    console.error('Error loading contributors.json:', err);
    return [];
  }
}

// Export for other modules (in environments that support modules this can be changed).
window.loadContributorsJson = loadContributorsJson;
